const express = require("express");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.urlencoded({extended: true}));
app.get("/",function(req,res){
  res.sendFile(__dirname+"/index.html");
});

app.post("/",function(req,res){
  // res.send("Thank you for posting!");
  var first = Number.parseInt(req.body.num1);
  var second =  Number.parseInt(req.body.num2);
  var result = first+second
  res.send("The sum is "+result);


});

app.listen("3000",function(){
  console.log("Server started at port 3000");
});
