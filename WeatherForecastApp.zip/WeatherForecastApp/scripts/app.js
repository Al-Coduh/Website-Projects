const express = require("express");
const https = require("https");
const bodyParser = require("body-parser");
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/", function (req, res) {
    res.sendFile("F:\\Programming\\WebDevelopment\\WeatherForecastApp\\index.html");
});

app.post("/",function(req,res){
    
    const query = req.body.cityName;
    const apikey = "5a1ece708629491fa20132403221110"
    const units = ""
    let url = `https://api.weatherapi.com/v1/current.json?key=${apikey}&q=${query}&aqi=no`
    console.log(query);
    https.get(url,function(response){
    response.on("data",function(data){
      const weatherdata = JSON.parse(data);
      const temperature = weatherdata.current.temp_c
      res.write(`<p>The weather is ${weatherdata.current.condition.text}</p>`)
      res.write(`<h1>The temperature is ${temperature} degree celcius</h1>`);
      res.write(`<img src=${weatherdata.current.condition.icon}>`)
    });
    });
});

app.listen("3000", function () {
    console.log("App started on port 3000");
});
